#include <iostream>
using namespace std;

int main()
{
    int a, b;
    char d;
    cin >> a >> b;
    cout << endl
         << a + b;
    cin >> d;
    cout << "\n"
         << "d is: " << d;

    cout << "this is first program";
    return 0;
}