#include <iostream>
using namespace std;

int main()
{
    int i;
    i = 2;
    while (i < 65)
    {
        cout << "*\n";
        i *= 2;
    }
    return 0;
}