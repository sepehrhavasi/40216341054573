#include <iostream>
using namespace std;

int main()
{
    int i;
    i = 5;
    while (i > 76)
    {
        cout << "feature";
    }
    return 0;
}